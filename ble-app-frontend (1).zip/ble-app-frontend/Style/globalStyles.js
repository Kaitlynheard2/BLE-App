import { StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';

const globalStyles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#1F1D1D',
    alignItems: 'left',
    justifyContent: 'left',
    padding:20,
  },

  graphWrapper: {
    padding:20,
  },

  splashView: {
    flex: 1,
    backgroundColor: '#1F1D1D',
    alignItems: 'center',
    justifyContent: 'center',
  },

  splashLogo: {
    width: '60%',
    alignContent: 'center',
    textAlign: 'center',
  },

  header: {
    fontFamily: 'sfprodisplay-bold',
    fontSize: 40,
    color: '#F2F2F2',
    margin: 20,
  },

  h2: {
    fontfamily: 'sfprodisplay-bold',
    color: '#F2F2F2',
    fontSize: 18,
    marginLeft:20,
    marginTop:0,
  },

  h3: {
    fontfamily: 'sfprodisplay-regular',
    color: '#F2F2F2',
    fontSize: 18,
  },

  h4: {
    fontfamily: 'sfprodisplay-regular',
    color: '#F2F2F2',
    fontSize: 14,
  },

  inactiveText: {
    color: '#828282',
  },

  cards: {
    flex: 1,
    backgroundColor: '#353232',
    borderRadius:10,
    justifyContent: 'center',
    alignItems: 'center',
    width: '90%',
    margin:20,
  },

  predictionText: {
    color: '#F76248',
  },
});

export default globalStyles;
