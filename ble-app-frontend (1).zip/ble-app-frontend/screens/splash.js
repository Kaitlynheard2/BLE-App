import * as React from 'react';
import { Text, View, StyleSheet, SafeAreaView } from 'react-native';
import globalStyles from '../Style/globalStyles';

export default function Splash() {
  return (
    <SafeAreaView style={globalStyles.splashView}>
      <Text style={[globalStyles.header, globalStyles.splashLogo]}>
        MERIIT Wearable Device
      </Text>
    </SafeAreaView>
  );
}
