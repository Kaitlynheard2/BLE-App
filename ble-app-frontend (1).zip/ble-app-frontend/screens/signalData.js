import * as React from 'react';
import { Text, View, StyleSheet, SafeAreaView } from 'react-native';
import globalStyles from '../Style/globalStyles';
import { VictoryLine, VictoryChart, VictoryTheme, VictoryZoomContainer } from "victory-native";
import Graph from "../components/graph";
import { Card } from 'react-native-paper';


export default function SignalData() {
    return(
      <SafeAreaView style={globalStyles.background}>
        <Text style={globalStyles.header}>Signal Data</Text>
        <Graph></Graph>
        <Text style={globalStyles.h2}>Output</Text>
        <Card style={globalStyles.cards}></Card>
      </SafeAreaView>
    )
  
}