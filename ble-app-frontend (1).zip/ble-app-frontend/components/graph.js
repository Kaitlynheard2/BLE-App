import * as React from 'react';
import { Text, View, StyleSheet, SafeAreaView } from 'react-native';
import globalStyles from '../Style/globalStyles';
import { VictoryLine, VictoryChart, VictoryTheme, VictoryZoomContainer, VictoryAxis } from "victory-native";


const data = [
      { x: 0, y: 2, z: 2 },
      { x: 2, y: 3, z: 3 },
      { x: 3, y: 5, z: 4 },
      { x: 4, y: 4, z: 3 },
      { x: 5, y: 7, z: 2 }
];
console.log(data)
export default class Graph extends React.Component {
  
  
  render() {
    return (
      <View style={globalStyles.graphWrapper}>
        <VictoryChart width={500} height={500} allowZoom={true} domainPadding={{ y: 10 }} theme={VictoryTheme.material} containerComponent={
    <VictoryZoomContainer zoomDomain={{x: [0,5], y: [0, 10]}}/>
  }>
          <VictoryLine data={data} style={{
      data: { stroke: "#F76248", strokeWidth:10, strokeLinecap: "round" },
      parent: { 
        backgroundStyle: '#353232'}
      
    }} />

    <VictoryAxis
  label="Time (ms)"
  style={{
    axis: {stroke:"#353232"},
    axisLabel: {fill:'#F2F2F2', fontSize: 25, padding: 35},
    grid: {stroke: "#353232"},
    ticks: {stroke: "#353232", size: 5},
    tickLabels: {fill:'#F2F2F2', fontSize: 15, padding: 5}
  }}
/>

 <VictoryAxis dependentAxis
  label="Acceleration"
  style={{
    axis: {stroke:"#353232"},
    axisLabel: {fill:'#F2F2F2', fontSize: 25, padding: 35},
    grid: {stroke: "#353232"},
    ticks: {stroke: "#353232", size: 5},
    tickLabels: {fill:'#F2F2F2', fontSize: 15, padding: 5}
  }}
/>
        </VictoryChart>
</View>
    );
  }
}
